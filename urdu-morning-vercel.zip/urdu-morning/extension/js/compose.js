/* Offline message composer: builds a message from the category pools.
 * Used by the browser when the API is unreachable, and by the bot as a fallback. */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory(require("./categories.js"), require("./urdu.js"));
  else root.Compose = factory(root.CATEGORIES, root.Urdu);
})(typeof self !== "undefined" ? self : this, function (C, U) {
  "use strict";
  const last = {};
  // random pick that never repeats the previous choice for the same pool
  function pick(arr, key) {
    if (!arr || !arr.length) return "";
    let i;
    do { i = Math.floor(Math.random() * arr.length); } while (arr.length > 1 && i === last[key]);
    last[key] = i;
    return arr[i];
  }
  const gender = (s, g) => s.replace(/\{([^{}|]*)\|([^{}|]*)\}/g, (_, m, f) => (g === "f" ? f : m));

  /**
   * @param {string} key category key
   * @param {{name?:string, relation?:string, gender?:"m"|"f", length?:"short"|"medium"|"long", emoji?:boolean}} o
   */
  function build(key, o = {}) {
    const cat = C.byKey[key] || C.CATS[0];
    const rel = C.RELATIONS[o.relation] || {};
    const g = rel.gender || o.gender || "m";
    const voc = C.vocative(o.relation, o.name, g);
    const len = o.length || "medium";
    const emoji = o.emoji !== false;

    const open = pick(cat.open, key + "o").replace("{n}", voc ? "، " + voc : "");
    const lines = [/[۔!؟]$/.test(open) ? open : open + "۔"];
    const body = pick(cat.body, key + "b");
    const isCouplet = body.includes("\n");
    lines.push(isCouplet ? "\n" + body + "\n" : body);
    if (len === "long" && !isCouplet && cat.body.length > 2) {
      let extra = pick(cat.body, key + "b2");
      if (extra === lines[1]) extra = cat.body.find(b => b !== lines[1]);
      lines.push(extra);
    }
    if (cat.verses && len !== "short") {
      const v = pick(cat.verses, key + "v");
      lines.push("", v.ar, v.ur + " (" + v.ref + ")", "");
    }
    const close = len === "short" ? "" : pick(cat.close, key + "c");
    const e = emoji ? " " + pick(cat.emoji, key + "e") : "";
    if (close) lines.push(close + e); else lines[lines.length - 1] += e;

    return U.normalize(gender(lines.join("\n"), g));
  }
  return { build };
});
