// Point this to your deployed server (https://your-app.onrender.com) or keep localhost for local use.
// If you use an https URL, also add it to "host_permissions" in manifest.json.
window.API_BASE = "http://localhost:3000";
