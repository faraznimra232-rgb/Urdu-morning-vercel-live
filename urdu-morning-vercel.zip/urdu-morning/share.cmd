@echo off
rem Gives your PC-hosted app a public link anyone can open (free Cloudflare quick tunnel).
rem 1) Run start.cmd first (keep that window open).  2) Run this file in a second window.
cd /d "%~dp0"
where cloudflared >nul 2>nul
if errorlevel 1 (
  echo cloudflared is not installed. Installing it now...
  winget install --id Cloudflare.cloudflared -e --accept-source-agreements --accept-package-agreements
  echo.
  echo Done. CLOSE this window, open share.cmd again.
  pause
  exit /b
)
echo.
echo Look for the line  https://something.trycloudflare.com  below - that is the link to send to people.
echo The link changes every time you restart this. Keep this window and start.cmd open. Ctrl+C to stop.
echo.
cloudflared tunnel --url http://localhost:3000
pause
