// Vercel entry point: the whole Express app runs as one serverless function (see vercel.json for the routing).
module.exports = require("../server.js");
