/* Renders a message onto a canvas as a WhatsApp-status / social image. */
(function (root) {
  "use strict";

  const THEMES = {
    fajr:  { name: "فجر",   swatch: "linear-gradient(#2b4a7a,#e98e4a,#f8cf85)", ink: "#ffffff", sub: "rgba(255,255,255,.85)", ar: "#fff3c9",
             bg(ctx, w, h) { const g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, "#22406f"); g.addColorStop(.6, "#d9804a"); g.addColorStop(1, "#f6c47c"); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
               const r = w * .22, cx = w / 2, cy = h - w * .08; const s = ctx.createRadialGradient(cx, cy, 0, cx, cy, r * 1.9);
               s.addColorStop(0, "rgba(255,244,210,.95)"); s.addColorStop(.35, "rgba(255,205,110,.65)"); s.addColorStop(1, "rgba(255,190,90,0)");
               ctx.fillStyle = s; ctx.fillRect(0, 0, w, h); ctx.fillStyle = "rgba(20,25,50,.18)"; ctx.fillRect(0, 0, w, h); } },
    sabz:  { name: "سبز",   swatch: "#0f3d2e", ink: "#f7ecd0", sub: "rgba(247,236,208,.8)", ar: "#f3d27a",
             bg(ctx, w, h) { ctx.fillStyle = "#0f3d2e"; ctx.fillRect(0, 0, w, h); pattern(ctx, w, h, "rgba(243,210,122,.09)"); frame(ctx, w, h, "#d8b45c"); } },
    raat:  { name: "رات",   swatch: "linear-gradient(#0b1530,#2d3f73)", ink: "#eef2ff", sub: "rgba(238,242,255,.75)", ar: "#ffe6a6",
             bg(ctx, w, h) { const g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, "#081026"); g.addColorStop(1, "#2d3f73"); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
               let seed = 7; const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
               for (let i = 0; i < 90; i++) { ctx.fillStyle = `rgba(255,255,255,${.2 + rnd() * .6})`; ctx.beginPath(); ctx.arc(rnd() * w, rnd() * h * .7, rnd() * 2.4 + .4, 0, 7); ctx.fill(); }
               const mx = w * .82, my = w * .16, mr = w * .06; ctx.fillStyle = "#fdf3d0"; ctx.beginPath(); ctx.arc(mx, my, mr, 0, 7); ctx.fill();
               ctx.fillStyle = "#0c1633"; ctx.beginPath(); ctx.arc(mx - mr * .45, my - mr * .2, mr * .9, 0, 7); ctx.fill(); } },
    gulab: { name: "گلاب",  swatch: "linear-gradient(#fde8ea,#f7c9cf)", ink: "#4a1f2c", sub: "rgba(74,31,44,.7)", ar: "#8c2d45",
             bg(ctx, w, h) { const g = ctx.createLinearGradient(0, 0, w, h); g.addColorStop(0, "#fff3f1"); g.addColorStop(1, "#f6c9d0"); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
               [[.08, .1, .2], [.95, .9, .26], [.9, .08, .1], [.05, .92, .12]].forEach(([x, y, r]) => { ctx.fillStyle = "rgba(214,110,135,.13)"; ctx.beginPath(); ctx.arc(x * w, y * h, r * w, 0, 7); ctx.fill(); }); } },
    kaghaz:{ name: "کاغذ", swatch: "#f4ead7", ink: "#2b2418", sub: "rgba(43,36,24,.65)", ar: "#1f3a5f",
             bg(ctx, w, h) { ctx.fillStyle = "#f6eddb"; ctx.fillRect(0, 0, w, h); frame(ctx, w, h, "#b58a4a"); } }
  };

  function pattern(ctx, w, h, color) { // subtle eight-pointed-star lattice
    const s = w / 9; ctx.strokeStyle = color; ctx.lineWidth = 2;
    for (let y = s / 2; y < h + s; y += s) for (let x = s / 2; x < w + s; x += s) {
      for (const a of [0, Math.PI / 4]) { ctx.save(); ctx.translate(x, y); ctx.rotate(a); ctx.strokeRect(-s * .22, -s * .22, s * .44, s * .44); ctx.restore(); }
    }
  }
  function frame(ctx, w, h, color) {
    const m = w * .04; ctx.strokeStyle = color; ctx.lineWidth = 3; ctx.strokeRect(m, m, w - 2 * m, h - 2 * m);
    ctx.lineWidth = 1.2; ctx.strokeRect(m + 12, m + 12, w - 2 * m - 24, h - 2 * m - 24);
  }

  const FONTS = { nastaliq: '"Noto Nastaliq Urdu"', gulzar: '"Gulzar"', naskh: '"Noto Naskh Arabic"' };

  async function ensureFonts(font) {
    if (!document.fonts || !document.fonts.load) return;
    try {
      await Promise.all([
        document.fonts.load(`48px ${FONTS[font] || FONTS.nastaliq}`, "صبح بخیر"),
        document.fonts.load('48px "Amiri"', "بِسْمِ اللَّهِ"),
        document.fonts.load('32px "Noto Naskh Arabic"', "اردو")
      ]);
    } catch (_) { /* draw with fallback fonts */ }
  }

  function wrap(ctx, text, maxW) {
    const out = [];
    for (const para of text.split("\n")) {
      if (!para.trim()) { out.push(""); continue; }
      let line = "";
      for (const word of para.split(/\s+/)) {
        const t = line ? line + " " + word : word;
        if (ctx.measureText(t).width > maxW && line) { out.push(line); line = word; } else line = t;
      }
      out.push(line);
    }
    return out;
  }

  /** Lay out the message and draw it. Shrinks the font until it fits the safe area. */
  async function render(canvas, { text, theme = "fajr", size = "square", font = "nastaliq", sign = "", dateLine = "" }) {
    await ensureFonts(font);
    const W = 1080, H = size === "story" ? 1920 : 1080;
    canvas.width = W; canvas.height = H;
    const ctx = canvas.getContext("2d"), T = THEMES[theme] || THEMES.fajr;
    ctx.direction = "rtl"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    T.bg(ctx, W, H);

    const pad = W * .11, maxW = W - pad * 2, top = H * (size === "story" ? .16 : .12), bottom = H * (size === "story" ? .82 : .80);
    const nast = font !== "naskh", fam = FONTS[font] || FONTS.nastaliq;
    // a trailing "(سورۃ …)" reference gets its own smaller line so it never breaks mid-reference
    const REF = /^(.*\S)\s*(\((?:سورۃ|سورۂ|سنن|صحیح|درود|صحابۂ)[^()]*\))$/;
    const paras = [];
    for (const p of text.trim().split("\n")) { const m = p.match(REF); if (m) paras.push(m[1], "\u0000" + m[2]); else paras.push(p); }

    let fs = size === "story" ? 64 : 56, layout;
    for (; fs >= 26; fs -= 2) {
      layout = []; let hTot = 0;
      for (let p of paras) {
        const isRef = p.startsWith("\u0000"); if (isRef) p = p.slice(1);
        const isAr = Urdu.isArabic(p);
        const f = isRef ? `${Math.round(fs * .52)}px "Noto Naskh Arabic"` : isAr ? `${Math.round(fs * 1.02)}px "Amiri"` : `${fs}px ${fam}`;
        const lh = isRef ? fs * 1.1 : isAr ? fs * 1.9 : fs * (nast ? 2.15 : 1.8);
        ctx.font = f;
        const lines = p.trim() ? wrap(ctx, p, maxW) : [""];
        for (const l of lines) { const h = l ? lh : lh * .4; layout.push({ l, f, h, isAr, isRef }); hTot += h; }
      }
      if (hTot <= bottom - top) { layout.total = hTot; break; }
    }

    let y = top + (bottom - top - layout.total) / 2;
    for (const it of layout) {
      if (it.l) {
        ctx.font = it.f; ctx.fillStyle = it.isRef ? T.sub : it.isAr ? T.ar : T.ink;
        ctx.shadowColor = theme === "fajr" || theme === "raat" ? "rgba(0,0,0,.25)" : "transparent"; ctx.shadowBlur = 12;
        ctx.fillText(it.l, W / 2, y + it.h / 2);
      }
      y += it.h;
    }
    ctx.shadowColor = "transparent";

    // footer: signature + date
    ctx.fillStyle = T.sub;
    if (sign) { ctx.font = `${Math.round(W * .036)}px ${fam}`; ctx.fillText(sign, W / 2, H * (size === "story" ? .88 : .885)); }
    if (dateLine) { ctx.font = `${Math.round(W * .024)}px "Noto Naskh Arabic"`; ctx.fillText(dateLine, W / 2, H - W * .07); }
    return canvas;
  }

  root.Card = { THEMES, render };
})(typeof self !== "undefined" ? self : this);
