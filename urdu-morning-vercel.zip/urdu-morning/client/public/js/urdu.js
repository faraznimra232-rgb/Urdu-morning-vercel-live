/* Urdu text helpers — shared by the browser app, the extension and the Node server.
 * Works as a plain <script> (window.Urdu) or via require() in Node. */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.Urdu = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  // Arabic harakat (zabar, zer, pesh, tanween, shadd, sukun, khari zabar…)
  const HARAKAT_G = /[ً-ْٰ]/g;

  /**
   * Is this line fully-vowelled Arabic (Quran / dua)? Ordinary Urdu also uses a few
   * diacritics — تعالیٰ، رزقِ حلال، فوراً — so we look at density, not mere presence.
   */
  function isArabic(line) {
    const marks = (String(line).match(HARAKAT_G) || []).length;
    if (marks < 3) return false;
    const letters = (String(line).match(/[ؠ-يٱ-ۓ]/g) || []).length;
    return letters > 0 && marks / letters >= 0.3;
  }

  const URDU_DIGITS = "۰۱۲۳۴۵۶۷۸۹";

  /**
   * Fix common orthography mistakes that LLMs and some keyboards make in Urdu:
   * Arabic ي/ى/ك/ه → Urdu ی/ک/ہ, Latin punctuation → Urdu punctuation.
   * Lines carrying harakat are treated as Arabic (Quran / dua) and left untouched.
   */
  function normalize(text) {
    if (!text) return "";
    return String(text)
      .replace(/\r/g, "")
      .split("\n")
      .map(line => {
        if (isArabic(line)) return line.trim(); // Quran / dua — keep exactly
        return line
          .replace(/[يى]/g, "ی")
          .replace(/ك/g, "ک")
          // Arabic he (ه) at the start or end of a word is always gol he (ہ) in Urdu.
          // Mid-word it is ambiguous (بهی → بھی but بهت → بہت), so it is left alone.
          .replace(/ه(?=[\s،۔!؟:.,]|$)/g, "ہ")
          .replace(/(^|[\s،])ه/g, "$1ہ")
          .replace(/\s*\?/g, "؟")
          .replace(/\s*;/g, "؛")
          .replace(/\s*,\s*/g, "، ")
          .replace(/([^\d\s])\.(?=\s|$)/g, "$1۔")  // sentence-final full stop → ۔ (keeps 3.5)
          .replace(/\s+([،۔!؟])/g, "$1")
          .replace(/([،۔!؟])(?=[^\s\d،۔!؟"'”)\]])/g, "$1 ")
          .replace(/[ \t]{2,}/g, " ")
          .trim();
      })
      .join("\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  /** Remove quotes / preambles a model sometimes wraps around the answer. */
  function cleanModelOutput(text) {
    let t = String(text || "").replace(/<think>[\s\S]*?<\/think>/g, "").trim();
    t = t
      .replace(/\*\*|__|`+/g, "")                      // markdown bold / code
      .replace(/^\s*(#{1,6}|>|[-*•]|\d+[.)])\s+/gm, "")  // headings, quotes, bullets, numbering
      .replace(/\s*\([^()\u0600-\u06FF]*[A-Za-z]{3,}[^()\u0600-\u06FF]*\)/g, ""); // English notes in brackets
    // drop lines that are mostly Latin (e.g. "Here is your message:", "Note: …")
    t = t.split("\n").filter(l => {
      const latin = (l.match(/[A-Za-z]/g) || []).length, ur = (l.match(/[\u0600-\u06FF]/g) || []).length;
      return !(latin >= 3 && latin > ur);
    }).join("\n");
    t = t.replace(/^["'“”«»]+|["'“”«»]+$/gm, "").trim();
    return normalize(t);
  }

  /** Share of letters that are in Arabic-script blocks (used to reject bad model output). */
  function urduRatio(text) {
    const letters = String(text).match(/\p{L}/gu) || [];
    if (!letters.length) return 0;
    const ar = letters.filter(c => /[؀-ۿݐ-ݿﭐ-﷿ﹰ-﻿]/.test(c)).length;
    return ar / letters.length;
  }

  const toUrduDigits = s => String(s).replace(/\d/g, d => URDU_DIGITS[d]);

  const HIJRI_MONTHS = ["محرم الحرام", "صفر المظفر", "ربیع الاول", "ربیع الثانی", "جمادی الاول", "جمادی الثانی",
    "رجب المرجب", "شعبان المعظم", "رمضان المبارک", "شوال المکرم", "ذوالقعدہ", "ذوالحجہ"];
  const WEEKDAYS = ["اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ"];
  const MONTHS = ["جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"];

  /** { day, month (1-12), year } in the Umm al-Qura Hijri calendar, or null if unsupported. */
  function hijri(date = new Date()) {
    try {
      const parts = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura", { day: "numeric", month: "numeric", year: "numeric" })
        .formatToParts(date);
      const get = t => parseInt((parts.find(p => p.type === t) || {}).value, 10);
      const h = { day: get("day"), month: get("month"), year: get("year") };
      return h.day && h.month && h.year ? h : null;
    } catch (_) { return null; }
  }

  function dateLine(date = new Date(), urduDigits = true) {
    const d = urduDigits ? toUrduDigits : String;
    const g = `${WEEKDAYS[date.getDay()]}، ${d(date.getDate())} ${MONTHS[date.getMonth()]} ${d(date.getFullYear())}`;
    const h = hijri(date);
    return h ? { gregorian: g, hijri: `${d(h.day)} ${HIJRI_MONTHS[h.month - 1]} ${d(h.year)} ہجری` } : { gregorian: g, hijri: "" };
  }

  /** Special days the app can suggest a category for. */
  function occasion(date = new Date()) {
    const h = hijri(date);
    if (h && h.month === 9) return { key: "رمضان المبارک", label: "رمضان المبارک کا بابرکت مہینہ ہے — سحری کا پیغام بھیجیں؟ 🌙" };
    if (h && h.month === 10 && h.day <= 3) return { key: "عید مبارک", label: "عید الفطر مبارک! عید کا پیغام بھیجیں 🌙" };
    if (h && h.month === 12 && h.day >= 10 && h.day <= 13) return { key: "عید مبارک", label: "عید الاضحیٰ مبارک! عید کا پیغام بھیجیں 🐑" };
    if (date.getDay() === 5) return { key: "جمعہ مبارک", label: "آج جمعہ ہے — جمعہ مبارک کا پیغام بھیجیں؟ 🕌" };
    return null;
  }

  /** Greeting that fits the time of day. */
  function timeGreeting(date = new Date()) {
    const h = date.getHours();
    if (h >= 4 && h < 12) return "صبح بخیر";
    if (h >= 12 && h < 17) return "السلام علیکم"; // "دن بخیر" is an English calque — not idiomatic Urdu
    if (h >= 17 && h < 21) return "شام بخیر";
    return "شب بخیر";
  }

  return { isArabic, normalize, cleanModelOutput, urduRatio, toUrduDigits, hijri, dateLine, occasion, timeGreeting, HIJRI_MONTHS };
});
