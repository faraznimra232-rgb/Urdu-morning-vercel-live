// Tests the Ollama provider against a tiny fake Ollama server (no real model needed).
const test = require("node:test"), assert = require("node:assert");
const http = require("node:http");

let installed = ["gemma4:e4b"], chatBodies = [], reply = "صبح بخیر! اللہ آپ کا آج کا دن خوشیوں سے بھر دے۔ ☀️";
const server = http.createServer((req, res) => {
  let b = ""; req.on("data", c => b += c);
  req.on("end", () => {
    res.setHeader("Content-Type", "application/json");
    if (req.url === "/api/tags") return res.end(JSON.stringify({ models: installed.map(name => ({ name })) }));
    if (req.url === "/api/chat") {
      const body = JSON.parse(b); chatBodies.push(body);
      if ("think" in body) { res.statusCode = 400; return res.end(JSON.stringify({ error: "model does not support thinking" })); } // simulates an older Ollama
      if (body.stream && installed.includes(body.model)) { // like real Ollama: one JSON object per line
        res.setHeader("Content-Type", "application/x-ndjson");
        const chars = [...reply];
        for (let i = 0; i < chars.length; i += 8) res.write(JSON.stringify({ message: { content: chars.slice(i, i + 8).join("") }, done: false }) + "\n");
        return res.end(JSON.stringify({ message: { content: "" }, done: true, eval_count: 20, eval_duration: 2e9, prompt_eval_count: 300, prompt_eval_duration: 3e9, load_duration: 1e8, total_duration: 5.2e9 }) + "\n");
      }
      if (!installed.includes(body.model)) { res.statusCode = 404; return res.end(JSON.stringify({ error: "model not found" })); }
      return res.end(JSON.stringify({ message: { role: "assistant", content: reply } }));
    }
    res.statusCode = 404; res.end("{}");
  });
});

let G;
test.before(async () => {
  await new Promise(r => server.listen(0, r));
  process.env.AI_PROVIDER = "ollama";
  process.env.OLLAMA_URL = `http://127.0.0.1:${server.address().port}`;
  G = require("../lib/generate.js");
});
test.after(() => server.close());

test("generates Urdu with gemma4, retries without the think option when Ollama rejects it", async () => {
  const { message, model } = await G.generate({ category: "عمومی", name: "علی" });
  assert.strictEqual(model, "gemma4:e4b");
  assert.ok(chatBodies.some(b => b.think === false), "first request asks for no thinking");
  assert.ok(message.includes("صبح بخیر"));
  const body = chatBodies.at(-1);
  assert.strictEqual(body.stream, false);
  assert.strictEqual(body.messages[0].role, "system");
  assert.ok(body.options.num_ctx >= 4096);
});

test("modelStatus reports the local provider and installed model", async () => {
  const s = await G.modelStatus();
  assert.deepStrictEqual([s.ai, s.provider, s.models], [true, "ollama", ["gemma4:e4b"]]);
  assert.strictEqual(G.aiEnabled(), true);
});

test("streams pieces to onToken and still returns the cleaned final message", async () => {
  const parts = [];
  const { message, model } = await G.generate({ category: "عمومی" }, t => parts.push(t));
  assert.strictEqual(model, "gemma4:e4b");
  assert.ok(parts.length > 2, "text arrives in several pieces");
  assert.strictEqual(parts.join(""), reply);
  assert.ok(message.includes("صبح بخیر"));
  assert.strictEqual(chatBodies.at(-1).stream, true);
});

test("non-Urdu output is rejected with kind bad_output", async () => {
  reply = "Good morning my friend, have a nice day";
  await assert.rejects(() => G.generate({ category: "عمومی" }), e => e.kind === "bad_output");
  reply = "صبح بخیر! اللہ آپ کا آج کا دن خوشیوں سے بھر دے۔ ☀️";
});

test("no model installed → kind no_model", async () => {
  installed = []; await new Promise(r => setTimeout(r, 15_100)); // list cache is 15 s
  await assert.rejects(() => G.generate({ category: "عمومی" }), e => e.kind === "no_model");
});

test("Ollama not running → kind ai_down (fast, no retries)", async () => {
  await new Promise(r => server.close(r));
  installed = ["gemma4:e4b"]; await new Promise(r => setTimeout(r, 15_100));
  const t = Date.now();
  await assert.rejects(() => G.generate({ category: "عمومی" }), e => e.kind === "ai_down");
  assert.ok(Date.now() - t < 5000);
});
