// Renders PNG icons from public/icon.svg (needs Playwright: npx playwright / global install).
const { chromium } = require("playwright");
const fs = require("fs"), path = require("path");
const svg = fs.readFileSync(path.join(__dirname, "../public/icon.svg"), "utf8");
const maskable = svg.replace(/rx="112"/, 'rx="0"');
(async () => {
  const b = await chromium.launch(), p = await b.newPage();
  const out = [["public/icon-192.png", 192, svg], ["public/icon-512.png", 512, svg], ["public/icon-maskable-512.png", 512, maskable],
    ["extension/icon16.png", 16, svg], ["extension/icon48.png", 48, svg], ["extension/icon128.png", 128, svg]];
  for (const [file, s, src] of out) {
    await p.setViewportSize({ width: s, height: s });
    await p.setContent(`<style>*{margin:0}body{background:transparent}svg{width:${s}px;height:${s}px;display:block}</style>${src}`);
    await p.screenshot({ path: path.join(__dirname, "..", file), omitBackground: true });
  }
  await b.close(); console.log("icons written");
})();
